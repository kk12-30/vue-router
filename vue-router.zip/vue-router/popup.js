const DEBUG_MODE = true;

async function executeSafe(func) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func,
      world: 'MAIN'
    });
    return results[0]?.result;
  } catch (error) {
    return { error: error.message };
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('scanBtn');
  const result = document.getElementById('result');
  const status = document.getElementById('status');
  
  btn.addEventListener('click', async () => {
    status.textContent = "Initializing scan...";
    result.textContent = "";
    
    try {
      const envCheck = await executeSafe(() => {
        return {
          hasVue: !!document.querySelector('[data-v-app]'),
          consoleAccess: typeof console !== 'undefined'
        };
      });
      
      if (DEBUG_MODE) console.log('Environment check:', envCheck);
      if (envCheck.error) throw new Error(envCheck.error);


      const scanResult = await executeSafe(() => {
        const debug = {
          log: (...args) => window.console?.log('[VueDetector]', ...args)
        };
        
        const findVueRoot = () => {
          const candidates = [
            document.querySelector('[data-v-app]'),
            document.querySelector('#app'),
            document.body
          ];
          
          for (const el of candidates) {
            if (el?.__vue__ || el?.__vue_app__) {
              debug.log('Found Vue instance at:', el);
              return el;
            }
          }
          return null;
        };

        const parseRoutes = (root) => {
          try {
            const router = root.__vue_app__?.config.globalProperties.$router ||
                          root.__vue__?._router;
            return router?.options?.routes || [];
          } catch (e) {
            return [];
          }
        };

        try {
          const vueRoot = findVueRoot();
          if (!vueRoot) return { error: 'VUE_ROOT_NOT_FOUND' };
          
          const routes = parseRoutes(vueRoot);
          if (routes.length === 0) return { error: 'NO_ROUTES' };
          
          const flatten = (routes, base = '') => routes.flatMap(r => {
            const path = `${base}/${r.path}`.replace(/\/+/g, '/');
            return [path].concat(r.children ? flatten(r.children, path) : []);
          });
          
          return {
            success: true,
            paths: [...new Set(flatten(routes))]
              .map(p => p.replace(/^\/+/, ''))
              .filter(p => p)
          };
        } catch (e) {
          return { error: e.message };
        }
      });


      if (DEBUG_MODE) console.log('Scan result:', scanResult);
      
      if (scanResult?.success) {
        result.textContent = scanResult.paths.join('\n');
        status.textContent = `Found ${scanResult.paths.length} routes`;
      } else {
        const errors = {
          'VUE_ROOT_NOT_FOUND': 'Vue application not detected',
          'NO_ROUTES': 'No route configuration found',
          'NO_ROUTER': 'Vue Router not installed'
        };
        status.textContent = errors[scanResult?.error] || 'Detection failed';
        result.textContent = scanResult?.error || 'Unknown error';
      }
      
    } catch (error) {
      status.textContent = 'System error';
      result.textContent = error.message;
      console.error('Full error:', error);
    }
  });
});